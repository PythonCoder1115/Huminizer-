
import asyncio
import base64
import json
import os
import re
import threading
import time
from pathlib import Path
BROWSER_WIDTH  = 400
BROWSER_HEIGHT = 580
MAX_CONCURRENT = 3
TASK_TIMEOUT   = 90       
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(BASE_DIR)
EXTENSION_DIR = os.path.join(PROJECT_ROOT, "extension")
EXT_CONFIG_FILE = os.path.join(EXTENSION_DIR, "config.json")
CONFIG_FILE = os.path.join(PROJECT_ROOT, "config.json")
HTML_TEMPLATE = """<!DOCTYPE html>
<html><head>
<script src="https://js.hcaptcha.com/1/api.js?onload=hcaptchaOnLoad" async defer></script>
</head><body>
<div class="h-captcha" data-sitekey="SITE_KEY"></div>
</body></html>"""
def _load_config():
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}
def sync_api_key():
    
    config = _load_config()
    api_key = config.get("9captcha", {}).get("api_key", "")
    vps_url = config.get("9captcha", {}).get("vps_url", "https://9captcha-api.pridesmp.fun")
    if not api_key:
        print("  [EXT] No 9Captcha API key in config.json")
        return False
    try:
        import requests
        resp = requests.post(
            f"{vps_url}/captcha/api/activate",
            json={"api_key": api_key},
            timeout=10
        )
        data = resp.json()
        if not data.get("success"):
            print(f"  [EXT] ✗ Key validation failed: {data.get('error', 'Unknown')}")
            return False
        solver_key = data.get("solver_key", "")
        backend_url = data.get("backend_url", "https://9captcha-api.pridesmp.fun/captcha/api/ext")
        credit = data.get("credit", 0)
        if credit <= 0:
            print(f"  ✗ Key validation failed: Insufficient credits ({credit})")
            return False
        ext_cfg = {}
        if os.path.exists(EXT_CONFIG_FILE):
            try:
                with open(EXT_CONFIG_FILE, "r") as f:
                    ext_cfg = json.load(f)
            except Exception:
                pass
        ext_cfg["api_key"] = api_key
        with open(EXT_CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(ext_cfg, f, indent=4)
        return api_key
    except Exception as e:
        print(f"  [EXT] ✗ Key exchange failed: {e}")
        return None
def _is_token_like(value):
    if not isinstance(value, str):
        return False
    token = value.strip()
    if len(token) < 25:
        return False
    return bool(re.search(r"[A-Za-z0-9_.-]{25,}", token))
def _encode_base64(text):
    return base64.b64encode(text.encode("utf-8")).decode("utf-8")
class ExtensionBrowser:
    
    def __init__(self):
        self.browser = None
        self.browser_lock = asyncio.Lock()
        self.semaphore = None
        self._initialized = False
        self._loop = None
        self._loop_thread = None
    def _ensure_loop(self):
        
        if self._loop and self._loop.is_running():
            return
        def run():
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)
            self._loop.run_forever()
        self._loop_thread = threading.Thread(target=run, daemon=True)
        self._loop_thread.start()
        for _ in range(50):
            if self._loop and self._loop.is_running():
                break
            time.sleep(0.1)
    async def _init_async(self):
        
        if self._initialized and self.browser:
            return
        import truedriver as td
        self.semaphore = asyncio.Semaphore(MAX_CONCURRENT)
        solver_key = sync_api_key()
        extension_dir = os.path.abspath(EXTENSION_DIR)
        browser_args = [
            "--disable-infobars",
            "--disable-dev-shm-usage",
            "--no-first-run",
            "--lang=fr-FR",
            "--disable-background-networking",
            "--disable-background-timer-throttling",
            "--disable-renderer-backgrounding",
            "--disable-backgrounding-occluded-windows",
            "--disable-ipc-flooding-protection",
            "--disable-hang-monitor",
            "--remote-debugging-port=0",
            "--enable-unsafe-extension-debugging",
            "--no-sandbox",
            "--disable-features=CalculateNativeWinOcclusion",
            f"--window-size={BROWSER_WIDTH},{BROWSER_HEIGHT}",
        ]
        ext_exists = os.path.exists(extension_dir) and Path(extension_dir).joinpath("manifest.json").exists()
        if ext_exists:
            browser_args.append(f"--disable-extensions-except={extension_dir}")
            browser_args.append(f"--load-extension={extension_dir}")
            browser_args.append(
                "--disable-features=DisableDisableExtensionsExceptCommandLineSwitch,DisableLoadExtensionCommandLineSwitch"
            )
        self.browser = await asyncio.wait_for(
            td.start(browser_args=browser_args, sandbox=False, headless=False),
            timeout=45,
        )
        self._initialized = True
        if solver_key and isinstance(solver_key, str):
            try:
                await self.browser.get(f"https://9captcha-api.pridesmp.fun/setup#key={solver_key}|base_api=https://9captcha-api.pridesmp.fun/captcha/api/ext")
                await asyncio.sleep(4)
            except Exception as e:
                print(f"  [EXT] ✗ Failed to inject API key into storage: {e}")
    async def _solve_async(self, sitekey, url, rqdata="", user_agent="", timeout=TASK_TIMEOUT):
        
        import truedriver as td
        from truedriver.cdp.fetch import HeaderEntry, RequestPattern, RequestStage
        from truedriver.cdp.network import ResourceType
        if not self._initialized:
            await self._init_async()
        await self.semaphore.acquire()
        page = None
        target_base_url = url.split("?", 1)[0]
        template_body = HTML_TEMPLATE.replace("SITE_KEY", sitekey)
        hcap_path = os.path.join(BASE_DIR, "hcaptcha.html")
        hcap_html = ""
        try:
            hcap_html = Path(hcap_path).read_text(encoding="utf-8")
        except Exception:
            hcap_html = "<html><body>hcaptcha template</body></html>"
        if rqdata:
            hcap_html = hcap_html.replace('Dr = t', f'Dr = "{rqdata}"')
            hcap_html = hcap_html.replace('Zr = t', f'Zr = "{rqdata}"')
        try:
            page = await self.browser.get("about:blank")
            async def request_handler(event):
                request_url = event.request.url
                handled = False
                try:
                    if request_url == url or request_url.startswith(target_base_url):
                        await page.send(td.cdp.fetch.fulfill_request(
                            request_id=event.request_id, response_code=200,
                            response_headers=[HeaderEntry("Content-Type", "text/html; charset=utf-8")],
                            body=_encode_base64(template_body),
                        ))
                        handled = True
                    elif "/static/hcaptcha.html" in request_url:
                        await page.send(td.cdp.fetch.fulfill_request(
                            request_id=event.request_id, response_code=200,
                            response_headers=[HeaderEntry("Content-Type", "text/html; charset=utf-8")],
                            body=_encode_base64(hcap_html),
                        ))
                        handled = True
                    if not handled:
                        await page.send(td.cdp.fetch.continue_request(request_id=event.request_id))
                except Exception:
                    pass
            handler_patterns = [
                RequestPattern(url_pattern=f"{target_base_url}*", request_stage=RequestStage.REQUEST, resource_type=ResourceType.DOCUMENT),
                RequestPattern(url_pattern="*static/hcaptcha.html*", request_stage=RequestStage.REQUEST, resource_type=ResourceType.DOCUMENT),
                RequestPattern(url_pattern="*api.js*", request_stage=RequestStage.REQUEST, resource_type=None),
            ]
            await page.send(td.cdp.fetch.enable(patterns=handler_patterns, handle_auth_requests=True))
            page.add_handler(td.cdp.fetch.RequestPaused, request_handler)
            await page.get(url, timeout=10)
            await page.evaluate("""
                Object.defineProperty(document, 'hidden', { get: () => false });
                Object.defineProperty(document, 'visibilityState', { get: () => 'visible' });
                document.dispatchEvent(new Event('visibilitychange'));
            """)
            start = time.time()
            while time.time() - start < timeout:
                try:
                    token = await page.evaluate("hcaptcha.getResponse()")
                    if token and _is_token_like(token):
                        elapsed = time.time() - start
                        # Trigger backend extension billing proxy
                        try:
                            import requests
                            cfg = _load_config()
                            api_key = cfg.get("9captcha", {}).get("api_key", "")
                            vps_url = cfg.get("9captcha", {}).get("vps_url", "https://9captcha-api.pridesmp.fun")
                            if api_key:
                                requests.post(f"{vps_url}/captcha/api/report_extension", json={
                                    "api_key": api_key, "siteurl": url, "task_type": "hcaptcha_basic", "token": token
                                }, timeout=5)
                        except Exception as e:
                            print(f"  [EXT] ✗ Failed to broadcast proxy track: {e}")
                        return token
                except Exception:
                    pass
                await asyncio.sleep(1)
            print(f"  [EXT] ✗ Timeout after {timeout}s")
            return None
        except Exception as e:
            print(f"  [EXT] ✗ Error: {e}")
            return None
        finally:
            if page:
                try:
                    page.remove_handlers(td.cdp.fetch.RequestPaused, request_handler)
                    await page.send(td.cdp.fetch.disable())
                except Exception:
                    pass
            self.semaphore.release()
    def solve(self, sitekey, url, rqdata="", user_agent="", timeout=TASK_TIMEOUT):
        
        self._ensure_loop()
        future = asyncio.run_coroutine_threadsafe(
            self._solve_async(sitekey, url, rqdata, user_agent, timeout),
            self._loop,
        )
        try:
            return future.result(timeout=timeout + 10)
        except Exception as e:
            print(f"  [EXT] Solve error: {e}")
            return None
    def is_ready(self):
        return self._initialized and self.browser is not None

    def stop(self):
        if self.browser:
            try:
                future = asyncio.run_coroutine_threadsafe(self.browser.stop(), self._loop)
                future.result(timeout=5)
            except Exception:
                pass

_browser = None
def get_browser():
    global _browser
    if _browser is None:
        _browser = ExtensionBrowser()
    return _browser
